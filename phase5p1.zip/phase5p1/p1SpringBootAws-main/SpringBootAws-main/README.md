# SpringBootAws

DESCRIPTION

As a Full Stack Developer, you have to build a CI/CD pipeline to demonstrate continuous deployment and host the application on AWS EC2 instance.

 

Background of the problem statement: 

As the project is in the final stage, management has asked you to automate the integration and deployment of the web application. You are required to set up an environment where the application will be hosted and accessed by users. The source code is supposed to be fetched from a GitHub repository.

 

You must use the following: 

Eclipse

GitHub

Jenkins

AWS EC2/ Virtual machine
